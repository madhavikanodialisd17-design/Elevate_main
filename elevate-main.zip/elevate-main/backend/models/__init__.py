# Specialist diagnostic models
